import './App.css';
import Users from './Users';

function App() {
  return (
    <div className="App">
      <Users></Users>
    </div>
  );
}

export default App;
