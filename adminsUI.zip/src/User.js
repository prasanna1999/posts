import React from "react";
import { Checkbox, Icon } from "@fluentui/react";
import { initializeIcons } from '@fluentui/react/lib/Icons';
import './User.css';

initializeIcons();
export default function User(props) {
    return <div className='ms-Grid-row user'>
            <Checkbox
                className="ms-Grid-col ms-sm1 checkbox"
                id={props.user.id}
                checked={props.isSelected}
                onChange={props.onUserSelected}
            />
            <div className="ms-Grid-col ms-sm5 ms-md5 ms-xl3 name">{props.user.name}</div>
            <div className="ms-Grid-col ms-sm6 ms-md6 ms-xl3 email">{props.user.email}</div>
            <div className="ms-Grid-col ms-sm6 ms-md6 ms-xl3 role">{props.user.role}</div>
            <div className="ms-Grid-col ms-sm6 ms-md6 ms-xl2 actions">
                <Icon iconName="SingleColumnEdit" onClick={props.onEditSelected}></Icon>
                <Icon iconName="Delete" onClick={props.onDeleteSelected} className="delete"></Icon>
            </div>
        </div>
}