import React from "react";
import axios from "axios";
import './Users.css';
import { Checkbox, Dialog, Icon, DialogFooter, PrimaryButton, DefaultButton, TextField, DialogType } from "@fluentui/react";
import { initializeIcons } from '@fluentui/react/lib/Icons';
import ReactPaginate from 'react-paginate';
import User from './User';
import _ from 'lodash';
initializeIcons();
export default class Users extends React.Component {
    itemsPerPage = 10;
    constructor(props) {
        super(props);
        this.state = {
            users: [],
            searchValue: '',
            filteredUsers: [],
            currentItems: [],
            pageCount: 0,
            itemOffset: 0,
            isEdit: false,
            editedUser: null,
            checkedIds: [],
            isSelectAllChecked: false,
            errMsgs: []
        }
    }
    componentDidMount() {
        axios.get('https://geektrust.s3-ap-southeast-1.amazonaws.com/adminui-problem/members.json').then((response) => {
            if (response) {
                let endOffset = this.state.itemOffset + this.itemsPerPage;
                this.setState({
                    users: response.data,
                    filteredUsers: response.data,
                    searchValue: '',
                    currentItems: response.data.slice(this.state.itemOffset, endOffset),
                    pageCount: (Math.ceil(response.data.length / this.itemsPerPage)),
                    editedUser: null
                });
            }
        })
    }

    handleChange = (e) => {
        let searchedValue = e.target.value;
        let endOffset = this.state.itemOffset + this.itemsPerPage;
        this.setState({ searchValue: searchedValue });
        searchedValue = searchedValue.toLowerCase();
        if (searchedValue.length > 0) {
            let filteredUsers = this.state.users.filter(
                (user) => user.name.toLowerCase().includes(searchedValue) ||
                    user.email.toLowerCase().includes(searchedValue) ||
                    user.role.toLowerCase().includes(searchedValue)
            );
            this.setState({
                filteredUsers: filteredUsers,
                currentItems: filteredUsers.slice(this.state.itemOffset, endOffset),
                pageCount: (Math.ceil(filteredUsers.length / this.itemsPerPage))
            });
        }
        else
            this.setState({
                filteredUsers: this.state.users,
                currentItems: this.state.users.slice(this.state.itemOffset, endOffset),
                pageCount: (Math.ceil(this.state.users.length / this.itemsPerPage))
            });
    }

    handleEdit = (id) => {
        let _editedUser = this.state.users.filter((user) => user.id == id)[0];
        this.setState({ isEdit: true, editedUser: _editedUser });
    }

    handleEditChange = (e) => {
        let id = e.target.id;
        let errMsg = this.validate(id, e.target.value);
        let _user = _.clone(this.state.editedUser);
        let _errMsgs = this.state.errMsgs;
        _errMsgs[id] = errMsg;
        _user[id] = e.target.value;
        this.setState({ editedUser: _user, errMsgs: _errMsgs });
    }

    validate = (id, val) => {
        const emailRegex = /\S+@\S+\.\S+/;
        switch (id) {
            case 'name':
                if (val.length == 0)
                    return 'Name is required';
                break;
            case 'email':
                if (val.length == 0)
                    return 'Email is required';
                else if (!emailRegex.test(val))
                    return 'Please enter valid email';
                break;
            case 'role':
                if (val.length == 0)
                    return 'Role is required';
                break;
            default:
                return null;
        }
    }

    handleUpdate = () => {
        let id = this.state.editedUser.id;

        let index = this.state.users.findIndex((_user) => _user.id == id);
        let _users = this.state.users;
        _users[index] = this.state.editedUser;
        let endOffset = this.state.itemOffset + this.itemsPerPage;
        this.setState({
            users: _users,
            filteredUsers: _users,
            currentItems: _users.slice(this.state.itemOffset, endOffset),
            isEdit: false
        });
    }

    handleDelete = (id) => {
        let _users = this.state.users.filter((user) => user.id != id);
        let endOffset = this.state.itemOffset + this.itemsPerPage;
        this.setState({
            users: _users,
            filteredUsers: _users,
            currentItems: _users.slice(this.state.itemOffset, endOffset),
            pageCount: (Math.ceil(_users.length / this.itemsPerPage))
        })
    }

    handlePageClick = (event) => {
        const newOffset = (event.selected * this.itemsPerPage) % this.state.filteredUsers.length;
        console.log(
            `User requested page number ${event.selected}, which is offset ${newOffset}`
        );
        this.setState({ itemOffset: newOffset });
        const endOffset = newOffset + this.itemsPerPage;
        this.setState({
            itemOffset: newOffset,
            currentItems: this.state.filteredUsers.slice(newOffset, endOffset),
            pageCount: Math.ceil(this.state.filteredUsers.length / this.itemsPerPage),
            checkedIds: [],
            isSelectAllChecked: false
        });
    };

    handleSelectAll = (e) => {
        this.setState({
            isSelectAllChecked: !this.state.isSelectAllChecked,
            checkedIds: e.target.checked ? this.state.currentItems.map((user) => { return user.id }) : []
        })
    }

    handleSelectChange = (id) => {
        let _isChecked = this.state.checkedIds.findIndex(_id => _id == id) >= 0;
        let _checkedIds = _.clone(this.state.checkedIds);
        if (_isChecked) {
            this.setState({
                checkedIds: this.state.checkedIds.filter(_id => _id != id),
                isSelectAllChecked: false
            })
        }
        else {
            _checkedIds.push(id);
            this.setState({ checkedIds: _checkedIds })
        }
    }

    deleteSelected = () => {
        let _users = _.clone(this.state.users);
        _users = _users.filter((user) => this.state.checkedIds.findIndex(item => item == user.id) >= 0 ? false : true);
        let endOffset = this.state.itemOffset + this.itemsPerPage;
        this.setState({
            users: _users,
            filteredUsers: _users,
            searchValue: '',
            currentItems: _users.slice(this.state.itemOffset, endOffset),
            pageCount: (Math.ceil(_users.length / this.itemsPerPage)),
            editedUser: null,
            checkedIds: [],
            isSelectAllChecked: false
        });
    }

    render() {
        return <div className='usersContainer'>
            <TextField
                placeholder="Search"
                onChange={this.handleChange}
                value={this.state.searchValue}
                className="searchBar"
            />
            <div className="ms-Grid-row user heading">
                <Checkbox className="ms-Grid-col ms-sm1 checkbox" onChange={this.handleSelectAll} checked={this.state.isSelectAllChecked} />
                <div className="ms-Grid-col ms-sm5 ms-md5 ms-xl3 name">Name</div>
                <div className="ms-Grid-col ms-sm6 ms-md5 ms-xl3 email">Email</div>
                <div className="ms-Grid-col ms-sm6 ms-md5 ms-xl3 role">Role</div>
                <div className="ms-Grid-col ms-sm6 ms-md6 ms-xl2 actions">Actions</div>
            </div>
            {this.state.currentItems.map(user => {
                return <User
                    user={user}
                    isSelected={this.state.checkedIds && this.state.checkedIds.filter((_id) => _id == user.id) && this.state.checkedIds.filter((_id) => _id == user.id)[0] >= 0 ? true : false}
                    onUserSelected={() => this.handleSelectChange(user.id)}
                    onEditSelected={() => this.handleEdit(user.id)}
                    onDeleteSelected={() => this.handleDelete(user.id)}
                />

            })}
            <Dialog
                hidden={!this.state.isEdit}
                modalProps={{
                    isBlocking: true,
                    containerClassName: `ms-dialogMainOverride`
                }}
                dialogContentProps={{
                    type: DialogType.normal,
                    title: 'Update User'
                }}
                minWidth={450}
            >
                <div>
                    <TextField id='name' value={this.state.editedUser?.name} onChange={this.handleEditChange} placeholder='Name' errorMessage={this.state.errMsgs.name} />
                    <TextField id='email' value={this.state.editedUser?.email} onChange={this.handleEditChange} placeholder='Email' errorMessage={this.state.errMsgs.email} />
                    <TextField id='role' value={this.state.editedUser?.role} onChange={this.handleEditChange} placeholder='Role' errorMessage={this.state.errMsgs.role} />
                </div>
                <DialogFooter>
                    <PrimaryButton
                        onClick={this.handleUpdate}
                        text='Update'
                        disabled = {!(this.state.errMsgs.name==undefined&&this.state.errMsgs.email==undefined&&this.state.errMsgs.role==undefined)}
                    />
                    <DefaultButton
                        onClick={() => { this.setState({ isEdit: false }) }}
                        text='Cancel'
                    />
                </DialogFooter>
            </Dialog>
            <PrimaryButton text={'Delete Selected'} onClick={this.deleteSelected} disabled={!this.state.checkedIds.length} className="deleteSelected" />
            <ReactPaginate
                breakLabel="..."
                nextLabel=">"
                onPageChange={this.handlePageClick}
                pageRangeDisplayed={5}
                pageCount={this.state.pageCount}
                previousLabel="<"
                renderOnZeroPageCount={null}
                className='paginate'
                pageLinkClassName='paginateItem'
                activeLinkClassName="selectedPaginateItem"
                previousLinkClassName='paginateItem'
                nextLinkClassName="paginateItem"
                previousClassName="paginateLi"
                nextClassName="paginateLi"
                pageClassName="paginateLi"
            />
        </div>
    }
}